package services;

import entities.VenteLocation;
import utils.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VenteLocationService {
    private Connection connection;

    public VenteLocationService() {
        connection = DBConnection.getInstance().getConnection();
    }

    public List<VenteLocation> findAll() throws SQLException {
        List<VenteLocation> venteLocations = new ArrayList<>();
        String query = "SELECT vl.* FROM vente_location vl " +
                "JOIN parcelle p ON vl.parcelle_id = p.id " +
                "WHERE p.status = TRUE";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                VenteLocation vl = new VenteLocation();
                vl.setId(rs.getInt("id"));
                vl.setParcelleId(rs.getInt("parcelle_id"));
                vl.setTypeOperation(rs.getString("type_operation"));
                vl.setPrix(rs.getBigDecimal("prix"));
                vl.setDateOperation(rs.getDate("date_operation").toLocalDate());
                vl.setStatut(rs.getBoolean("statut"));
                venteLocations.add(vl);
            }
        }
        return venteLocations;
    }

    public void save(VenteLocation venteLocation) throws SQLException {
        String query = "INSERT INTO vente_location (parcelle_id, type_operation, prix, date_operation, statut) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, venteLocation.getParcelleId());
            pstmt.setString(2, venteLocation.getTypeOperation());
            pstmt.setBigDecimal(3, venteLocation.getPrix());
            pstmt.setDate(4, Date.valueOf(venteLocation.getDateOperation()));
            pstmt.setBoolean(5, venteLocation.getStatut());
            pstmt.executeUpdate();
        }
    }

    public void update(VenteLocation venteLocation) throws SQLException {
        String query = "UPDATE vente_location SET parcelle_id = ?, type_operation = ?, prix = ?, date_operation = ?, statut = ? WHERE id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, venteLocation.getParcelleId());
            pstmt.setString(2, venteLocation.getTypeOperation());
            pstmt.setBigDecimal(3, venteLocation.getPrix());
            pstmt.setDate(4, Date.valueOf(venteLocation.getDateOperation()));
            pstmt.setBoolean(5, venteLocation.getStatut());
            pstmt.setInt(6, venteLocation.getId());
            pstmt.executeUpdate();
        }
    }

    public void delete(int id) throws SQLException {
        String query = "DELETE FROM vente_location WHERE id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        }
    }

}