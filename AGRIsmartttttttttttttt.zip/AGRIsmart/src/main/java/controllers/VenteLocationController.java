package controllers;

import entities.VenteLocation;
import services.VenteLocationService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalDate;

public class VenteLocationController {

    @FXML private TableView<VenteLocation> venteLocationTable;
    @FXML private Button addButton;
    @FXML private Button modifyButton;
    @FXML private Button deleteButton;

    private VenteLocationService venteLocationService = new VenteLocationService();
    private ObservableList<VenteLocation> venteLocationList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        setupTableColumns();
        loadVenteLocations();
    }

    private void setupTableColumns() {
        TableColumn<VenteLocation, Integer> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));

        TableColumn<VenteLocation, Integer> parcelleIdCol = new TableColumn<>("Parcelle ID");
        parcelleIdCol.setCellValueFactory(new PropertyValueFactory<>("parcelleId"));

        TableColumn<VenteLocation, String> typeCol = new TableColumn<>("Type");
        typeCol.setCellValueFactory(new PropertyValueFactory<>("typeOperation"));

        TableColumn<VenteLocation, BigDecimal> prixCol = new TableColumn<>("Prix");
        prixCol.setCellValueFactory(new PropertyValueFactory<>("prix"));

        TableColumn<VenteLocation, LocalDate> dateCol = new TableColumn<>("Date");
        dateCol.setCellValueFactory(new PropertyValueFactory<>("dateOperation"));

        TableColumn<VenteLocation, String> statutCol = new TableColumn<>("Statut");
        statutCol.setCellValueFactory(new PropertyValueFactory<>("statut"));

        venteLocationTable.getColumns().addAll(idCol, parcelleIdCol, typeCol, prixCol, dateCol, statutCol);
    }

    private void loadVenteLocations() {
        try {
            venteLocationList.setAll(venteLocationService.findAll());
            venteLocationTable.setItems(venteLocationList);
        } catch (SQLException e) {
            showAlert("Erreur", "Erreur lors du chargement des données: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleAdd() {
        try {
            VenteLocation vl = new VenteLocation();
            vl.setParcelleId(3); // Example parcel ID, replace with dynamic input
            vl.setTypeOperation("vente"); // Example, replace with user input
            vl.setPrix(new BigDecimal("60000.00")); // Example, replace with user input
            vl.setDateOperation(LocalDate.now()); // Current date
            vl.setStatut(false); // Example, replace with user input
            venteLocationService.save(vl);
            loadVenteLocations();
        } catch (SQLException e) {
            showAlert("Erreur", "Erreur lors de l'ajout: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleModify() {
        VenteLocation selected = venteLocationTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            try {
                selected.setStatut(false);
                venteLocationService.update(selected);
                loadVenteLocations();
            } catch (SQLException e) {
                showAlert("Erreur", "Erreur lors de la modification: " + e.getMessage(), Alert.AlertType.ERROR);
            }
        } else {
            showAlert("Avertissement", "Veuillez sélectionner une ligne à modifier.", Alert.AlertType.WARNING);
        }
    }

    @FXML
    private void handleDelete() {
        VenteLocation selected = venteLocationTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            try {
                venteLocationService.delete(selected.getId());
                venteLocationList.remove(selected);
                loadVenteLocations();
            } catch (SQLException e) {
                showAlert("Erreur", "Erreur lors de la suppression: " + e.getMessage(), Alert.AlertType.ERROR);
            }
        } else {
            showAlert("Avertissement", "Veuillez sélectionner une ligne à supprimer.", Alert.AlertType.WARNING);
        }
    }

    private void showAlert(String title, String message, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}